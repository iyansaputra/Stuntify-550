package com.ninis.stuntify

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ninis.stuntify.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // Setup click listeners for the buttons
        binding.btnPendataanKualitasGizi.setOnClickListener {
            navigateToKualitasGizi()
        }

        binding.btnRekomendasiMakanan.setOnClickListener {
            navigateToRekomendasi()
        }
    }

    private fun navigateToKualitasGizi() {
        // Intent untuk perpindahan ke halaman pendataan kualitas gizi
        val intent = Intent(this, KualitasGiziActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToRekomendasi() {
        // Intent untuk perpindahan ke halaman rekomendasi makanan
        val intent = Intent(this, RekomendasiActivity::class.java)
        startActivity(intent)
    }
}