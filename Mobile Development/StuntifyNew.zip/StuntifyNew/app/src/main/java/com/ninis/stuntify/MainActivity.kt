package com.ninis.stuntify

import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.ninis.stuntify.ui.auth.RegisterActivity
import com.ninis.stuntify.data.RegisterResponse
import com.ninis.stuntify.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var data: RegisterResponse? = null

    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment_activity_main) as NavHostFragment
        val navController: NavController = navHostFragment.navController
        navView.setupWithNavController(navController)

        if (savedInstanceState == null) {
            navController.navigate(R.id.navigation_home)
        }

        val intent = intent
        val data = intent.getParcelableExtra<RegisterResponse>(RegisterActivity.EXTRA_DATA)
    }
}