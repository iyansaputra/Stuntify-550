package com.ninis.stuntify.data

import android.os.Parcel
import android.os.Parcelable
import kotlinx.parcelize.Parceler
import kotlinx.parcelize.Parcelize

data class RegisterBody(
    var name: String,
    var email: String,
    var asal_kota: String,
    var umur: String
)

@Parcelize
data class RegisterResponse(
    val message: String,
    val data: UserData
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readParcelable(UserData::class.java.classLoader) ?: UserData("", "", "", "")
    )

    companion object : Parceler<RegisterResponse> {

        override fun RegisterResponse.write(parcel: Parcel, flags: Int) {
            parcel.writeString(message)
            parcel.writeParcelable(data, flags)
        }

        override fun create(parcel: Parcel): RegisterResponse {
            return RegisterResponse(parcel)
        }
    }
}

@Parcelize
data class UserData(
    val name: String,
    val email: String,
    val asal_kota: String,
    val umur: String
): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: ""
    )

    companion object : Parceler<UserData> {

        override fun UserData.write(parcel: Parcel, flags: Int) {
            parcel.writeString(name)
            parcel.writeString(email)
            parcel.writeString(asal_kota)
            parcel.writeString(umur)
        }

        override fun create(parcel: Parcel): UserData {
            return UserData(parcel)
        }
    }
}

