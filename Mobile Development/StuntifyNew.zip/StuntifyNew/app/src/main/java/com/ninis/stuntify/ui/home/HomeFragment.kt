package com.ninis.stuntify.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Article
import com.ninis.stuntify.databinding.FragmentHomeBinding
import com.ninis.stuntify.ui.recommendation.RecommendationActivity

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val recyclerView = binding.recyclerViewArticles
        val articleAdapter = ArticleAdapter(getDummyArticles()) { article ->
            navigateToDetail(article)
        }
        recyclerView.adapter = articleAdapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

        binding.btnRekomendasiMakanan.setOnClickListener {
            navigateToRekomendasi()
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun navigateToDetail(article: Article) {
        val intent = Intent(requireContext(), DetailArticleActivity::class.java)
        intent.putExtra("article", article)
        startActivity(intent)
    }

    private fun getDummyArticles(): List<Article> {
        return listOf(
            Article.create(getString(R.string.article_title1), getString(R.string.article_content1), R.drawable.img_article1),
            Article.create(getString(R.string.article_title2), getString(R.string.article_content2), R.drawable.img_article2),
            Article.create(getString(R.string.article_title3), getString(R.string.article_content3), R.drawable.img_article3)
        )
    }

    private fun navigateToRekomendasi() {
        val intent = Intent(requireContext(), RecommendationActivity::class.java)
        startActivity(intent)
    }
}