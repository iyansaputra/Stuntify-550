package com.ninis.stuntify.ui.recommendation

import android.os.Bundle
import android.text.Html
import android.text.Spanned
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Recipe
import com.ninis.stuntify.databinding.FragmentDetailBinding
import java.lang.StringBuilder

class DetailFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private lateinit var binding: FragmentDetailBinding
    private lateinit var recipe: Recipe

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        arguments?.let {
            recipe = it.getParcelable(ARG_RECIPE)!!
            displayRecipeDetails(recipe)
        }
    }

    private fun displayRecipeDetails(recipe: Recipe) {
        binding.tvNamaMakanan.text = recipe.nama_makanan
        binding.tvBahan.text = formatBulletPoints(recipe.bahan_makanan)
        binding.tvLove.text = recipe.loves.toString()
        binding.tvTakaran.text = formatBulletPoints(recipe.takaran)
        binding.tvInstruksi.text = formatBulletPoints2(recipe.instruksi)
    }

    private fun formatBulletPoints(text: String): Spanned {
        val items = text.split(",")
        val formattedText = StringBuilder()
        for (item in items) {
            formattedText.append("\u2022 $item<br/>")
        }
        return Html.fromHtml(formattedText.toString(), Html.FROM_HTML_MODE_LEGACY)
    }

    private fun formatBulletPoints2(text: String): Spanned {
        val items = text.split(".")
        val formattedText = StringBuilder()
        for (item in items) {
            formattedText.append("\u2022 $item<br/>")
        }
        return Html.fromHtml(formattedText.toString(), Html.FROM_HTML_MODE_LEGACY)
    }

    companion object {
        const val ARG_RECIPE = "recipe"

        @JvmStatic
        fun newInstance(recipe: Recipe) =
            DetailFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(ARG_RECIPE, recipe)
                }
            }
    }
}