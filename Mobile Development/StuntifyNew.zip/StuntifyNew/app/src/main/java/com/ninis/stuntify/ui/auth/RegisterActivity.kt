package com.ninis.stuntify.ui.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.ninis.stuntify.MainActivity
import com.ninis.stuntify.data.RegisterBody
import com.ninis.stuntify.data.RegisterResponse
import com.ninis.stuntify.databinding.ActivityRegisterBinding
import com.ninis.stuntify.remote.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private var registerResponse: RegisterResponse? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.registButton.setOnClickListener {
            if (registerResponse != null) {
                navigateToMainActivity()
            } else {
                register()
            }
        }
    }

    private fun register() {
        val nama = binding.edtNama.text.toString()
        val email = binding.edtEmail.text.toString()
        val asal_kota = binding.edtKota.text.toString()
        val umur = binding.edtUmur.text.toString()

        val userData = RegisterBody(nama, email, asal_kota, umur)

        performRegistration(userData)
    }

    private fun performRegistration(userData: RegisterBody) {
        ApiConfig.apiService.createUser(userData).enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                if (response.isSuccessful) {
                    val apiResponse = response.body()
                    showToast("Registrasi berhasil")
                    apiResponse?.let {
                        registerResponse = it
                        navigateToMainActivity()
                    }
                } else {
                    showToast("Gagal melakukan registrasi. Silakan coba lagi.")
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                showToast("Gagal melakukan registrasi. Periksa koneksi internet Anda.")
            }
        })
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra(EXTRA_DATA, registerResponse)
        startActivity(intent)
        finish()
    }

    companion object {
        const val EXTRA_DATA = "extra_data"
    }
}