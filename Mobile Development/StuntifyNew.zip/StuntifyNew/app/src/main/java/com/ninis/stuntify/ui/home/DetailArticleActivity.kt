package com.ninis.stuntify.ui.home

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar
import com.ninis.stuntify.MainActivity
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Article
import com.ninis.stuntify.databinding.ActivityDetailArticleBinding

class DetailArticleActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailArticleBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailArticleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolbar: MaterialToolbar = binding.toolbar

        toolbar.setNavigationOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        val article = intent.getSerializableExtra("article") as Article

        binding.titleArticle.text = article.title
        binding.contentArticle.text = article.content
        binding.imageArticle.setImageResource(article.imageResId)
    }
}