package com.ninis.stuntify.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

data class RecipeResponse(
    val message: String,
    val data: List<Recipe>
)

@Parcelize
data class Recipe(
    val id: String,
    val nama_makanan: String,
    val bahan_makanan: String,
    val loves: Int,
    val takaran: String,
    val instruksi: String
) : Parcelable

