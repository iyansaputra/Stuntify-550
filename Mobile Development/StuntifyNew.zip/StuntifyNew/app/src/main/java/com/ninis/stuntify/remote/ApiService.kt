package com.ninis.stuntify.remote

import com.ninis.stuntify.data.RecipeResponse
import com.ninis.stuntify.data.RegisterBody
import com.ninis.stuntify.data.RegisterResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Url

interface ApiService {
    @POST("users")
    fun createUser(@Body userData: RegisterBody): Call<RegisterResponse>

    @GET
    fun searchRecipes(@Url url: String): Call<RecipeResponse>
}