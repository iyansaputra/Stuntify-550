package com.ninis.stuntify.ui.recommendation

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentTransaction
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Recipe
import com.ninis.stuntify.databinding.FragmentItemListBinding
import com.ninis.stuntify.ui.recommendation.placeholder.PlaceholderContent

class ItemFragment : Fragment(), ItemAdapter.OnItemClickListener {

    private var columnCount = 1
    private lateinit var adapter: ItemAdapter
    private var recipes: List<Recipe> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            columnCount = it.getInt(ARG_COLUMN_COUNT)
            recipes = it.getParcelableArrayList(ARG_RECIPES)!!
        }
        adapter = ItemAdapter(PlaceholderContent.ITEMS, this)
    }

    fun updateRecipeList(newItems: List<Recipe>) {
        PlaceholderContent.updateItems(newItems)
        adapter.notifyDataSetChanged()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentItemListBinding.inflate(inflater, container, false) // Use data binding
        adapter = ItemAdapter(recipes, this) // Use the retrieved recipes
        binding.list.apply {
            layoutManager = when {
                columnCount <= 1 -> LinearLayoutManager(context)
                else -> GridLayoutManager(context, columnCount)
            }
            adapter = this@ItemFragment.adapter
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (view is RecyclerView) {
            with(view) {
                layoutManager = when {
                    columnCount <= 1 -> LinearLayoutManager(context)
                    else -> GridLayoutManager(context, columnCount)
                }

                adapter = ItemAdapter(PlaceholderContent.ITEMS, this@ItemFragment)
                this.adapter = adapter
                this.adapter = adapter
            }
        }
    }

    companion object {
        const val ARG_COLUMN_COUNT = "column-count"
        const val ARG_RECIPES = "recipes"

        @JvmStatic
        fun newInstance(columnCount: Int, recipes: List<Recipe>) =
            ItemFragment().apply {
                arguments = Bundle().apply {
                    putInt(ARG_COLUMN_COUNT, columnCount)
                    putParcelableArrayList(ARG_RECIPES, ArrayList(recipes))
                }
            }
    }

    override fun onItemClick(recipe: Recipe) {
        val transaction: FragmentTransaction = requireActivity().supportFragmentManager.beginTransaction()
        val fragment = DetailFragment.newInstance(recipe)
        transaction.replace(R.id.fragmentContainer, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }
}