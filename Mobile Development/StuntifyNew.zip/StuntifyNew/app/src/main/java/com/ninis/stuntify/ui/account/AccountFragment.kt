package com.ninis.stuntify.ui.account

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.button.MaterialButton
import com.ninis.stuntify.ui.auth.RegisterActivity
import com.ninis.stuntify.data.RegisterResponse
import com.ninis.stuntify.databinding.FragmentAccountBinding

class AccountFragment : Fragment() {
    private var _binding: FragmentAccountBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAccountBinding.inflate(inflater, container, false)

        val root: View = binding.root
        val logoutButton: MaterialButton = binding.logoutButton

        val intent = requireActivity().intent
        val registerResponse = intent.getParcelableExtra<RegisterResponse>(RegisterActivity.EXTRA_DATA)
        Log.d("AccountFragment", "RegisterResponse: $registerResponse")

        registerResponse?.data?.let {
            binding.tvNama.text = it.name
            binding.tvEmail.text = it.email
            binding.tvKota.text = it.asal_kota
            binding.tvUmur.text = it.umur
        }

        logoutButton.setOnClickListener {
            requireActivity().intent.removeExtra(RegisterActivity.EXTRA_DATA)
            val registerIntent = Intent(requireActivity(), RegisterActivity::class.java)
            startActivity(registerIntent)
            requireActivity().finish()
        }

        return root
    }
}