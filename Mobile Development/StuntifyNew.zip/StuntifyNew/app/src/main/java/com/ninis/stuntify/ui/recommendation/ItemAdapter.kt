package com.ninis.stuntify.ui.recommendation

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Recipe
import com.ninis.stuntify.databinding.FragmentItemBinding

class ItemAdapter(
    private val values: List<Recipe>,
    private val itemClickListener: OnItemClickListener
) : RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(FragmentItemBinding.inflate(
                LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = values[position]
        holder.contentView.text = item.nama_makanan
        holder.contentDetails.text = item.bahan_makanan
        holder.contentLoves.text = item.loves.toString()
        holder.itemView.setOnClickListener {
            itemClickListener.onItemClick(item)
        }
    }

    interface OnItemClickListener {
        fun onItemClick(recipe: Recipe)
    }

    override fun getItemCount(): Int = values.size

    inner class ViewHolder(binding: FragmentItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val contentView: TextView = binding.itemTitle
        val contentDetails: TextView = binding.content
        val contentLoves: TextView = binding.tvLove

        override fun toString(): String {
            return super.toString() + " '" + contentView.text + "'"
        }
    }

}