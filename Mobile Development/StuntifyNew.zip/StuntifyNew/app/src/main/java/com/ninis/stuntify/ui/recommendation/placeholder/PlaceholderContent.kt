package com.ninis.stuntify.ui.recommendation.placeholder

import com.ninis.stuntify.data.Recipe

object PlaceholderContent {

    val ITEMS: MutableList<Recipe> = ArrayList()

    private val COUNT = 25

    init {
        for (i in 1..COUNT) {
            addItem(createPlaceholderItem(i))
        }
    }

    private fun addItem(item: Recipe) {
        ITEMS.add(item)
    }

    fun updateItems(newItems: List<Recipe>) {
        ITEMS.clear()
        ITEMS.addAll(newItems)
    }

    private fun createPlaceholderItem(position: Int): Recipe {
        return Recipe(
            id = position.toString(),
            nama_makanan = "Item $position",
            bahan_makanan = makeDetails(position),
            loves = position,
            takaran = "Takaran placeholder $position",
            instruksi = "Instruksi placeholder $position"
        )
    }

    private fun makeDetails(position: Int): String {
        val builder = StringBuilder()
        builder.append("Details about Item: ").append(position)
        for (i in 0..position) {
            builder.append("\nMore details information here.")
        }
        return builder.toString()
    }
}