package com.ninis.stuntify.data

import java.io.Serializable

data class Article(
    val title: String,
    val content: String,
    val imageResId: Int
) : Serializable {
    companion object {
        fun create(title: String, content: String, imageResId: Int): Article {
            return Article(title, content, imageResId)
        }
    }
}
