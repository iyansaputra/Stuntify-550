package com.ninis.stuntify.ui.recommendation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.ninis.stuntify.R
import com.ninis.stuntify.data.Recipe
import com.ninis.stuntify.data.RecipeResponse
import com.ninis.stuntify.databinding.FragmentInputRecommendationBinding
import com.ninis.stuntify.remote.ApiConfig
import com.ninis.stuntify.ui.recommendation.placeholder.PlaceholderContent
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class InputRecommendationFragment : Fragment() {
    private var _binding: FragmentInputRecommendationBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentInputRecommendationBinding.inflate(inflater, container, false)
        val view = binding.root

        val btnSave: Button = view.findViewById(R.id.btnSimpan)

        btnSave.setOnClickListener {
            searchRecipes()
        }

        return view
    }

    private fun buildDynamicSearchUrl(bahan1: String, vararg bahan: String?): String {
        val baseUrl = "http://capstonestuntify.et.r.appspot.com/stuntify/resep/search/"
        val nonEmptyBahanList = mutableListOf(bahan1, *bahan.filterNotNull().toTypedArray())
        val dynamicPath = nonEmptyBahanList.filter { it.isNotBlank() }.joinToString("/")
        return baseUrl + dynamicPath
    }


    private fun searchRecipes() {
        val bahan1 = binding.edtBahan1.text.toString()
        val bahan2 = binding.edtBahan2.text.toString()
        val bahan3 = binding.edtBahan3.text.toString()
        val bahan4 = binding.edtBahan4.text.toString()
        val bahan5 = binding.edtBahan5.text.toString()

        if (bahan1.isNotEmpty() || bahan2.isNotEmpty() || bahan3.isNotEmpty() || bahan4.isNotEmpty() || bahan5.isNotEmpty()) {
            val dynamicSearchUrl = buildDynamicSearchUrl(bahan1, bahan2, bahan3, bahan4, bahan5)

            ApiConfig.apiService.searchRecipes(dynamicSearchUrl)
                .enqueue(object : Callback<RecipeResponse> {
                    override fun onResponse(
                        call: Call<RecipeResponse>,
                        response: Response<RecipeResponse>
                    ) {
                        if (response.isSuccessful) {
                            val recipeResponse = response.body()
                            if (recipeResponse != null) {
                                val recipes = recipeResponse.data
                                showToast("Jumlah Resep Ditemukan: ${recipes.size}")
                                PlaceholderContent.updateItems(recipes)
                                showRecipeList(recipes)
                                (requireActivity().supportFragmentManager
                                    .findFragmentById(R.id.fragmentContainer)
                                        as? ItemFragment)?.updateRecipeList(recipes)
                            }
                        } else {
                            showToast("Gagal mencari resep. Silakan coba lagi.")
                        }
                    }

                    override fun onFailure(call: Call<RecipeResponse>, t: Throwable) {
                        showToast("Gagal mencari resep. Periksa koneksi internet Anda.")
                    }
                })
        } else {
            showToast("Harap masukkan setidaknya satu bahan untuk mencari resep.")
        }
    }

    private fun showRecipeList(recipes: List<Recipe>) {
        val transaction: FragmentTransaction = requireActivity().supportFragmentManager.beginTransaction()
        val fragment = ItemFragment.newInstance(1, recipes)
        transaction.replace(R.id.fragmentContainer, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}